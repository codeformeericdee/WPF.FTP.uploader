﻿namespace ftpuploader.secret
{
    public class Secret
    {
        public string URI = "ftp://waws-prod-bay-217.ftp.azurewebsites.windows.net/netftp";
        public string Path = "c:\\julia-verea-eoi4sNjjAXU-unsplash.jpg";
        public string FileName = "juliavereaimage.jpg";
        public string UserName = "ericmarystoystore\\$ericmarystoystore";
        public string Password = "uTZ2cnetKQjpaniCw6KpHMdakNama9fx6rrkaBcb0HqjBzLxkg0QkTnyje9B";
    }
}